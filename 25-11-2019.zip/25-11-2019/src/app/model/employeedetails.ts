import { Skill } from './skills';

export class EmployeeDetails{
    id: number; 
	candidateName: String;
    interName: String;
    skills:Skill[];
}