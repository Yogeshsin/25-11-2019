import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {FormGroup, FormBuilder, Validators} from '@angular/forms';
import { EmployeeDetails } from 'src/app/model/employeedetails';
import { EmployeedetailsService } from 'src/app/service/employeedetails.service';
import { Observable } from 'rxjs';
import { Skill } from 'src/app/model/skills';

@Component({
  selector: 'app-l1form',
  templateUrl: './l1form.component.html',
  styleUrls: ['./l1form.component.css']
})

export class L1formComponent implements OnInit {
  employee: EmployeeDetails = new EmployeeDetails();
  skill:Skill=new Skill();
  skills:Skill[];
  employees: Observable<EmployeeDetails[]>;
  submitted = false;
  ngForm: FormGroup;
  invalidLogin: boolean=false;


  textBoxDisabled = true;
  
  toggle(){
    this.textBoxDisabled = !this.textBoxDisabled;
  }

textBoxDisabled1 = true;
  
  toggle1(){
    this.textBoxDisabled1 = !this.textBoxDisabled1;
  }

// myClickFunction(event) { 
//   alert("Registration Successful");
//   console.log(event);
// }


  list: any = [
    {id: 1, name: 'Java'},
    {id: 2, name: 'Angular 6'},
    {id: 3, name: 'Node Js'},
    {id: 4, name: 'Express Js'}
  ];
  current = 1;
  log = '';

  logDropdown(id: number): void {
    const NAME = this.list.find((item: any) => item.id === +id).name;
    this.log += `${NAME} \n`;
    console.log(this.log)
    this.skill.skillName=this.log;
  }

  name: any;

  constructor(private formBuilder: FormBuilder, private router: Router, private employeeDetailsService: EmployeedetailsService) { }

  ngOnInit() {

      this.reloadData();
    
    this.ngForm = this.formBuilder.group({
      cname: ['', Validators.required],
      desc: ['', Validators.required],
      skill: ['', Validators.required],
      flexibility: ['', Validators.required],
      ename: ['', Validators.required],
      ecode: ['', Validators.required],
    });
  }

  reloadData() {
    this.employees = this.employeeDetailsService.getemployeeDetailsList();
  
  }
  // newEmployeeDetails(): void {
  //   this.submitted = false;
  //   this.employee = new EmployeeDetails();
  // }
 
  save() {
    this.employeeDetailsService.createSkill(this.skill).subscribe(res=>this.skills[0]);
    this.employee.skills=this.skills;
    this.employeeDetailsService.createEmployeeDetails(this.employee)
      .subscribe(data => console.log(data), error => console.log(error));
    // this.employee = new EmployeeDetails();
    
  
  }  
  onSubmit() {
    this.submitted = true;
      this.save();
    // If validation failed, it should return 
    // to Validate again
    if (this.ngForm.invalid) {
    return;
    }
   
     this.router.navigate(['/form']);
  
    }
   
   
  
   

}
