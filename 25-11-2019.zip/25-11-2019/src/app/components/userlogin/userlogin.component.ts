import { Component, OnInit } from '@angular/core';

import {FormGroup, FormControl,FormBuilder, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { UserloginService } from 'src/app/service/userlogin.service';
import { Login } from 'src/app/model/userlogin';


@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {
  userarray:Login[];
  loginForm: FormGroup;
  submitted:boolean= false;
  invalidLogin: boolean=false;
  loading: boolean;
  
    constructor(private formBuilder: FormBuilder, private router: Router, private userloginservice:UserloginService) { }


      ngOnInit(){
        this.loginForm= new FormGroup({
          userName: new FormControl('',[Validators.required]),
          password:new FormControl('', [Validators.required])
          })

      }
  
    onSubmit() {
      this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
        return;
    }

    this.loading = true;
    this.userloginservice.getAdmin(this.loginForm.value).subscribe(
            data => {
                 this.router.navigate(['/form']);
            }
           
            );
}
     
 }